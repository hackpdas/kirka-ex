
alert("This hack was made by NOBODY#7386 and others and script was put together by amadu stickler ")

alert("To use menu use SHIFT+M")




javascript:(function() {
    var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = 'icon128.png';
    document.title='KIRKA HACKS';
    console.log(document.title);
    document.getElementsByTagName('head')[0].appendChild(link);
})();





