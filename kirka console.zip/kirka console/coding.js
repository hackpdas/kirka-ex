window.open("https://www.youtube.com/channel/UCZerH5L79RzgaCmXsqojlMw/", '_blank');

window.open("https://coding-team-join.w3spaces.com/", '_blank');
