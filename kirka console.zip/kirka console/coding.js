window.open("https://www.youtube.com/channel/UCZerH5L79RzgaCmXsqojlMw/", '_blank');

window.open("https://kirka.ml/", '_blank');
 
