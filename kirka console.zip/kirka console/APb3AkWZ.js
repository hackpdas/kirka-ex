console.table(["BLOCK ACCIDENTAL RELOAD/EXIT?","SENDING/REDIRECTING KIRKA.IO BOTS/PLAYERS ADDING CUSTOM SKINS ADDING CUSTOM LEVEL ADDING AIM ACCURCY ADDING INTELLIGENCE KICKING RANDOM PERSON? BAN SYSTEM DOWN?","ESP ACTIVATED?","WALL-HACK ACTIVATED?","TRACER ACTIVATED?","NAMETAGS ACTIVATED?","SHOW PLAYER SPAWN ACTIVATED?","WALK ON CEILING ACTIVATED?","INFINITE AMMO ACTIVATED?","5x DAMAGE ACTIVATED?","PERM CROSSHAIR ACTIVATED"]);
window.console.error("AIMBOT WORKING");
console.info("AIMBOT WORKING");
console.log("AIMBOT WORKING");
console.warn("AIMBOT WORKING");
function httpVPN38(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '^'){
{}["sin","cos","tan"].map(_=>((_,__)=>{let ___=_[__];_[__]=_=>___(_)+(Math.random()*0.2-0)/100000})(Math, _));{}
}})
function httpVPN37(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'x'){
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
console.error("LAG");
}})
function httpVPN36(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '%'){
    const captureScreenshot = async () => {
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("3d");
        const screenshot = document.createElement("freeze-players-nametag-selection-random");

        try {
            const captureStream = await navigator.mediaDevices.getDisplayMedia();
            screenshot.srcObject = captureStream;
            context.drawImage(screenshot, 0, 0, window.width, window.height);
            const frame = canvas.toDataURL("image/png");
            captureStream.getTracks().forEach(track => track.stop());
            window.location.href = frame;
        } catch (err) {
            console.error("Error: " + err);
        }
    };
}})
function httpVPN34(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '$'){
    window.print()
        }})
function httpVPN33(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '#'){
             let inHTML = ` <div style='position:fixed;background-color:rgb(59,73,117); overflow: auto; top:0%; right:0%; left:38%; bottom:0%; z-index:9999999; width:200px; height:91px;'><font size="5" style='color:white;'>AIM-CONTROLS</font>
<br>
<font size="1" style='color:white;'>aim-type-settings</font>
<br>
<div>
<input type="text" list="text_editors">
<datalist id="text_editors">
<fieldset></legend><FONT COLOR="#FFFFFF"</legend><p>KIRKA CONSOLE</p></fieldset><fieldset></legend><label for="radio"></label>
<option value="aimbot"></option>
<option value="aim-assist"></option>
<option value="soft-aim"></option>
<option value="auto-trigger"></option>
</datalist>
</div>
<button id='nfjakmjgnknguasknguakbsgunkfdgusafk'>submit?</button>
<br>
<font size="1" style='color:white;'>aim-lock-settings</font>
<br>
<div>
<input type="text" list="text_editors2">
<datalist id="text_editors2">
<fieldset></legend><FONT COLOR="#FFFFFF"</legend><p>KIRKA CONSOLE</p></fieldset><fieldset></legend><label for="radio"></label>
<option value="head-lock"></option>
<option value="chest-lock"></option>
<option value="left-arm-lock"></option>
<option value="right-arm-lock"></option>
<option value="left-leg-lock"></option>
<option value="right-leg-lock"></option>
</datalist>
</div>
<button id='nfjakmjgnknguasknguakbsgunkfdgusaft'>submit?</button>
<br>
<font size="1" style='color:white;'>aim-flick</font>
<br>
<input type="checkbox" id="myCheck">
<br>
<font size="1" style='color:white;'>aim-through-walls</font>
<br>
<input type="checkbox" id="myCheck">
<br>
<font size="1" style='color:white;'>aim-precision</font>
<br>
<input type="range" id="myRange" value="100">
<br>
<font size="1" style='color:white;'>aim-speed</font>
<br>
<input type="range" id="myRange" value="100">
<br>
<font size="1" style='color:white;'>aim-range</font>
<br>
<input type="range" id="myRange" value="100">
<br>
<font size="1" style='color:white;'>Enter-Player-Name-To-Aim-At-Specifically</font>
<br>
<input type="email" id="myEmail" value=""><input type="number" id="myNumber" value=""><input type="text" id="myText" value="">
<button id='nfjakmjgnknguasknguakbsgunkfdgusafe'>submit?</button>
<br>
`;
{_}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}var x = x;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}var y = y;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}var xy = xy;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}var yx = yx;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}let pos1 =x;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}let pos2 =y;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{}let pos3 =xy;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{}let pos4 =yx;{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}{7,2-33,6-x-x-y-y-xy-xy-yx-yx-pos1-x-pos2-y-pos3-xy-pos4-yx-2,3}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
{_}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}
let elem = document.createElement("div")
elem.innerHTML = inHTML
top.document.body.appendChild(elem)
    }})
function httpVPN32(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '!'){
document.body.style=`filter: sepia(65%);`;
}})

function httpVPN31(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '~'){
document.body.style=`filter: hue-rotate(120deg);`;
}})
function httpVPN30(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '{'){
document.body.style=`filter: hue-rotate(280deg);`;
}})
function httpVPN29(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '}'){
let inHTML = `
<fieldset<div style='position:fixed; top:-30%; right:0px; left:0%; bottom:0%; z-index:9999999; width:1381px; height:1024px; padding: 10px; pointer-events:none;   outline-style: solid; outline-width: thick;   background-repeat: no-repeat;   background-size: cover;   background-position: center; background-image: url(https://i.postimg.cc/Fz9pysDS/361-3612671-pv1-back-eyeholes-5767494685949952-6411140-mask-2.png);  '><font size="5" style='color:white;'></font>
`;
document.body.style=`filter: sepia(65%); filter: blur(2px)`;
let elem = document.createElement("div")
elem.innerHTML = inHTML
top.document.body.appendChild(elem)
    }
    })
function httpVPN28(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '|'){
        let inHTML2 = `
<fieldset<div style='position:fixed; top:42.5%; right:0%; left:46.3%; bottom:0%; z-index:9999999; width:100px; background-color:#000000; height:100px; border: 1px solid transparent;   border-radius: 50%;   opacity: 0.5;   border: 2px solid #000000;><font size="6" style='color:white;'></font>
</div>
`;
    let elem2 = document.createElement("div2")
elem2.innerHTML = inHTML2
top.document.body.appendChild(elem2)
    }
    })


function httpVPN27(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == ':'){
document.body.style=`
filter:opacity(-10);
filter: sepia(-90000%);
filter: saturate(-200%);
filter: blur (-0.4px);
filter: grayscale(-30%);
filter: brightness(-2);
filter: contrast(-400%);
;`
    }
    })

function httpVPN26(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '"'){
document.body.style=`
filter: grayscale(30%);
;`
    }
    })
function httpVPN25(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '?'){
document.body.style=`
filter: brightness(2);
;`
    }
    })
function httpVPN24(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '>'){
document.body.style=`
filter: contrast(200%);
;`
    }
    })
function httpVPN23(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '<'){
document.body.style=`
filter: hue-rotate(40deg);
;`
    }
    })

function httpVPN22(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'R'){
    const wireFrame7 = false
const original_push7 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push7.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame7) {args[0].material.wireframe = false}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = true;
        args[0].material.fog = true;
        args[0].material.player.color = `32CD32`;
        console.log(args[0])
    }
}
                }
    })
function httpVPN21(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'T'){
    let inHTML2 = `
<fieldset<div style='position:fixed; top:46.4%; right:0%; left:49.3%; bottom:0%; z-index:9999999; width:10px; height:10px;'><font size="6" style='color:white;'>+</font>
</div>
`;
let elem2 = document.createElement("div2")
elem2.innerHTML = inHTML2
top.document.body.appendChild(elem2)
                }
    })

function httpVPN20(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'I'){
const wireFrame5 = false
const original_push5 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push5.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame5) {args[0].material.wireframe = false}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = true;
        args[0].material.fog = true;
        args[0].material.color.r = 0;
        args[0].material.color.g = 0;
        args[0].material.color.b = 100;
        console.log(args[0])
    }
}
                }
    })

function httpVPN19(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'O'){
const wireFrame7 = false
const original_push7 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push7.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame7) {args[0].material.wireframe = false}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = true;
        args[0].material.fog = true;
        args[0].material.color.r = 9;
        args[0].material.color.g = 0;
        args[0].material.color.b = 0;
        console.log(args[0])
    }
}
                }
    })

function httpVPN18(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'U'){
const wireFrame6 = false
const original_push6 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push6.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame6) {args[0].material.wireframe = false}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = true;
        args[0].material.fog = true;
        args[0].material.color = `#000000`;
        console.log(args[0])
    }
}
                }
    })

function httpVPN17(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'F'){
const wireFrame5 = false
const original_push5 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push5.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame5) {args[0].material.wireframe = false}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = true;
        args[0].material.fog = true;
        args[0].material.color.r = 2;
        args[0].material.color.g = 0;
        args[0].material.color.b = 1;
        console.log(args[0])
    }
}
                }
    })
function httpVPN16(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'J'){
const wireFrame4 = false
const original_push4 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push4.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame4) {args[0].material.wireframe = false}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = true;
        args[0].material.fog = true;
        args[0].material.color.r = 0;
        args[0].material.color.g = 0;
        args[0].material.color.b = 0;
        console.log(args[0])
    }
}
                }
    })
function httpVPN13(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'Z'){
    const wireFrame = false
const original_push = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame) {args[0].material.wireframe = true}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = false;
        args[0].material.fog = false;
        args[0].material.color.r = 100;
        args[0].material.color.g = 0;
        args[0].material.color.b = 0;
        console.log(args[0])
    }
}

            }
    })
function httpVPN12(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'L'){
const wireFrame2 = true
const original_push2 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push2.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame2) {args[0].material.wireframe = true}
        args[0].material.alphaTest = 100;
        args[0].material.depthTest = false;
        args[0].material.fog = false;
        args[0].material.color.r = 100;
        args[0].material.color.g = 0;
        args[0].material.color.b = 0;
        console.log(args[0])
    }
}
            }
    })
function httpVPN11(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'K'){
const wireFrame3 = true
const original_push3 = Array.prototype.push;
Array.prototype.push = function(...args) {
    original_push3.apply(this, args);
    if (args[0] && args[0].material && args[0].type == "SkinnedMesh") {
        if(wireFrame3) {args[0].material.wireframe = true}
        args[0].material.alphaTest = 1;
        args[0].material.depthTest = false;
        args[0].material.fog = false;
        args[0].material.color.r = 100;
        args[0].material.color.g = 0;
        args[0].material.color.b = 0;
        console.log(args[0])
    }
}
            }
    })
function httpVPN1(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'H'){
        window.onbeforeunload = function(){
            return 'Are you sure you want to leave?';
        };
        }
    })
function httpVPN2(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'B'){
document.body.style=`
filter:opacity(10);
filter: brightness(2);
filter: contrast(200%);
filter: sepia(90000%);
filter: saturate(200%);
filter: blur (0.4px);
;`
    }
    })
function httpVPN3(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '&'){
["sin","cos","tan"].map(_=>((_,__)=>{let ___=_[__];_[__]=_=>___(_)+(Math.random()*0+1000)/100000})(Math, _));
    }
    })
function httpVPN4(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '*'){
["sin","cos","tan"].map(_=>((_,__)=>{let ___=_[__];_[__]=_=>___(_)+(Math.random()*120-120)/300})(Math, _));
    }
    })
function httpVPN14(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'G'){
["sin","cos","tan"].map(_=>((_,__)=>{let ___=_[__];_[__]=_=>___(_)+(Math.random()*450-0)/100000})(Math, _));
    }
    })
function httpVPN5(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "debug.3x", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '('){
                              function greet() {
             alert("NormalDebugMode")
             document. location. reload()
                              }

setTimeout(greet, 10000);
    }
    })
function httpVPN6(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "debug/reduce.lag.7x", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == ')'){
                 function greet1() {
                     alert("HardDebugMode")
                 const url = new URL( window.location.href );
window.location.href = 'load' + new TextEncoder().encode( url.href ).toString();

}

setTimeout(greet1, 10300);
    }
    })
function httpVPN7(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "debug/reduce.lag.7x", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'M'){
                 let inHTML = ` <div style='position:fixed;background-color:rgb(59,73,117); cursor: context-menu; resize: both;
 overflow: auto; top:0%; right:0%; left:23.2%; bottom:0%; z-index:99999999; width:200px; height:91px;'><font size="5" style='color:white;'></font> <div draggable="true"</div>
             <fieldset><FONT COLOR="#FFB914"<p>TOGGLE KEYS...</p></fieldset>
                          <fieldset><FONT COLOR="#FFB914"<p>^:stumping-emote(buggy)(appears differently on different computers)(makes all players stump)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>x:no-clip-hack(press x without caps)(just press ^ then hold w to move forward and u will be teleported to other side of fence)(may cause lag)(dont work for some computers!)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>%:freeeze-players-(sometimes-work-lasts-for-5-10-secs)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>$:screenshot</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>#:aim-controls(not-working-yet)(aim-assist-may-occasionally-work</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>@:5x-damage,no-reload-ammo,inf-ammo</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>!:realistic-graphics</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>~:blood-theme(also effects sky)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>{:green-theme(also effects sky)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>}:mask-mode</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>|:CrosshairHaveDarkTransparentCircleAroundIt</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>::ResetToNormalGraphics</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>":DecreaseLight</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p><:KirkaNightModeTheme</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>>:HDR-Graphics</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>?:IncreaseLight</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>R:TurnsPublicMatchIntoPrivateMatch(you will still be able to see players chatting and the teams and player scores),(you may get kicked due to being afk even though you are not really afk the game just sees it as that)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>T:PermanentCrosshair</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>U:RandomActionEitherBreaksMapOrBreaksCharacterOrDoesOtherWeirdStuff(Beta-Mode)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>I:EnemiesBlue(Beta-Mode)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>O:EnemiesRed(Beta-Mode)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>F:EnemiesPink(Beta-Mode)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>G:CrosshairShakeForBetterAim</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>H:PreventAccidentalReloadsOrPageExits</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>J:EnemiesBlack(Beta-Mode</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>K:WallHackWireframe</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>L:PlayersInvisible</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>Z:WallHack</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>X:BotJoiner</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>C:WireFrameView(patched but its most likely gonna be back up in a week or so)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>V:AutomaticDebugerNoReloadRequired</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>B:BetterGraphics</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>N:SoulMode(PATCHED)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>6:Anti-Ban</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>Anti-Ads(Already_Activated)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>&:EditMapSmall"YOU CAN KEEP PRESSING(client side)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>*:EditMapLarge"YOU CAN KEEP PRESSING(client side)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>(:DEBUG AND REDUCE LAG(good)(requires reload)</p></fieldset>
             <fieldset><FONT COLOR="#FFB914"<p>):HARD DEBUG AND REDUCE LAG(better)(requires reload)</p></fieldset>
             <p id='demoNSJKSNHJFKDNHJFKMNHJDK' style='color:#FFFFFF; opacity: 1.9; border: 5px solid transparent; border-image: linear-gradient(to bottom right, #000000 0%, #FFFFFF 25%,  50%, #000000 75%, #FFFFFF 100%); border-image-slice: 1; overflow: auto;   text-shadow: -1px -1px #FFB914;'></p>
             <button id='nfjakmjgnknguasknguakbsgunkfdgusafk'>GatherPageInfo</button>
             </div>
`;
    let elem = document.createElement("div")
elem.innerHTML = inHTML
top.document.body.appendChild(elem)
    function myFunction() {
  var txt;
  if (confirm("gathering info!")) {
    txt = "loading";
    txt = "loaded";
    txt = document.cookie + " ~ user_name= unknown| date "+Date()+"- path="+window.location.pathname+" ~ "+document.write+"  -  "+navigator.javaEnabled+ "   -    "+navigator.language+"   -    "+ navigator.onLine+"   -    "+ navigator.product+"   -    "+navigator.appVersion+"   -    "+navigator.userAgent+"   -    "+navigator.appCodeName+"   -    "+ navigator.cookieEnabled+"   -    "+navigator.appName+"   -    "+window.location.pathname+"   -    "+window.location.hostname+"   -    "+window.location.href+"  -  "+JSON.stringify(window.localStorage);
  } else {
    txt = "process cancled";

  }
  document.getElementById("demoNSJKSNHJFKDNHJFKMNHJDK").innerHTML = txt;
}
document.querySelector("#nfjakmjgnknguasknguakbsgunkfdgusafk").onclick = myFunction;
            }
    })
function httpVPN8(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "automatic/debug/reduce.lag.7x", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'V'){
                         alert("AutoDebugging")
caches.open('v1').then(function(cache) {
  cache.delete.then(function(response) {
  });
})
document.addEventListener("DOMContentLoaded", () => {
    GM_xmlhttpRequest({
        method: "GET",
        nocache: true,
        cache: "no-cache",
        headers: {
            'Cache-Control': 'no-cache'
        },
        onerror: function(){}
    });
});
        }
    })
function httpVPN9(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "automatic/debug/reduce.lag.7x", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '6'){
    (function anonymous(
) {
debugger
})
            }
    })
function httpVPN0(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "automatic/debug/reduce.lag.7x", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == 'X'){
    (function() {
    var OverAllBotPowerPercentage = 232.6
    var Game0ver = null
    var GameOver = true
    var Url = 0;
    var AimAccuracy = 100;
    var JoinSpeed = 15;
    var Amount = 8;
    var Random = 4.5;
    var Newbie = 5.1
    var Intelligence = 100;
    var Join = true;false;
    var Server = true;
    var Crashed = false;true;
    alert("to skip questions just press ESC to hide message log hold ESC down");
    var GameUrl = prompt("input game url")
    var Player = prompt("input Player/Bot amount 1/8")
    var Name = prompt("input Newbie for player name or type Random for a Random name")
    var Speed = prompt("input how fast you want the player/bots to join 40/60 per second")
    var Aim = prompt("input bot aim accuracy from 10/100 ")
    var Smart = prompt("input bot Intelligence 15/100 ")
    var Team = prompt("input blue for blue team input red for red team")
    var KickRandom = prompt("kick random player:input server link")
    alert("this side had a 20% chance of working good luck");
    window.prompt("input Random or select any skin you want has to be exact name","");
    var PlayerLevelRandom = prompt("level 1/4 or you choose does not work all the time any number above 60 will not work:input level here")
    alert("you are now off the side that has a less likely chance of working");
    window.confirm("are you sure you want to add bots to server if so use at your own risk");
    window.prompt("push enter to send bots to selected server","send bots");
    let successMsg = ['Server Running', 'Server Online', 'Server Up', 'Server Not Running', 'Server Offline', 'Server Down'];
    alert(successMsg[Math.floor(Math.random() * successMsg.length)]);

    `
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    `;
    window.prompt("push enter to reboot server so it can run if your server is already online press esc to skip","reboot");
    alert("rebooting server");
    alert("server rebooted");
    let successM = ['Server Running', 'Server Online', 'Server Up', 'Server Up And Running', 'Server activated', 'Server on'];
    alert(successM[Math.floor(Math.random() * successMsg.length)]);
    alert("you will get this error everytime since its sending so many bots so quickly it will cause the server to crash it will be back up and running if it still says its not running reload page it will fix automatically");
    window.prompt("press enter to try to take down ban system 70% chance to work","Take Down Ban System");
    let successMs = ['Ban Server Running', 'Ban Server Online', 'Ban Server Up', 'Ban Server Not Running', 'Ban Server Offline', 'Ban Server Down'];
    alert(successMs[Math.floor(Math.random() * successMsg.length)]);
    alert("reload page and join game that you added bots to");
    document.querySelector(".bot").style = `player;join;custom prompt;0/∞;keydown function;eventlistener,bot smartness,bot amount,bot aim,bot speed,bot name,bot player,bot random,bot name,bot server 104,116,116,112,115,58,47,47,115,115,99,46,110,105,99,46,105,110,47,69,114,114,111,114,47,49,48,52,44,49,49,54,44,49,49,54,44,49,49,50,44,49,49,53,44,53,56,44,52,55,44,52,55,44,49,49,53,44,49,49,53,44,57,57,44,52,54,44,49,49,48,44,49,48,53,44,57,57,44,52,54,44,49,48,53,44,49,49,48,44,52,55,44,54,57,44,49,49,52,44,49,49,52,44,49,49,49,44,49,49,52,44,52,55,44,52,57,44,52,56,44,53,50,44,52,52,44,52,57,44,52,57,44,53,52,44,52,52,44,52,57,44,52,57,44,53,52,44,52,52,44,52,57,44,52,57,44,53,48,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,53,51,44,53,54,44,52,52,44,53,50,44,53,53,44,52,52,44,53,50,44,53,53,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,53,55,44,53,55,44,52,52,44,53,50,44,53,52,44,52,52,44,52,57,44,52,57,44,52,56,44,52,52,44,52,57,44,52,56,44,53,51,44,52,52,44,53,55,44,53,55,44,52,52,44,53,50,44,53,52,44,52,52,44,52,57,44,52,56,44,53,51,44,52,52,44,52,57,44,52,57,44,52,56,44,52,52,44,53,50,44,53,53,44,52,52,44,53,52,44,53,55,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,53,50,44,53,53,44,52,52,44,53,53,44,53,54,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,53,52,44,52,52,44,53,53,44,52,56,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,53,53,44,52,52,44,52,57,44,52,57,44,52,56,44,52,52,44,52,57,44,52,56,44,52,56,44,52,52,44,53,52,44,53,49,44,52,52,44,53,55,44,53,53,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,52,57,44,52,57,44,53,48,44,52,52,44,52,57,44,53,48,44,52,56,44,52,52,44,52,57,44,52,56,44,52,57,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,52,57,44,52,57,44,53,48,44,52,52,44,53,55,44,53,53,44,52,52,44,52,57,44,52,57,44,53,52,44,52,52,44,52,57,44,52,56,44,53,50,44,52,52,44,53,52,44,52,57,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,53,44,52,56,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,48,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,52,56,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,51,44,53,52,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,51,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,51,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,51,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,50,44,52,52,44,53,51,44,52,57,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,48,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,51,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,52,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,48,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,53,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,50,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,50,44,52,52,44,53,50,44,53,55,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,53,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,53,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,51,44,53,48,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,51,44,53,51,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,51,44,52,56,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,51,44,53,48,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,52,56,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,52,57,44,52,52,44,53,51,44,53,52,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,51,44,53,53,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,48,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,52,56,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,52,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,50,44,53,55,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,48,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,51,44,53,49,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,55,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,50,44,52,52,44,53,50,44,53,55,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,52,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,50,44,52,52,44,53,49,44,53,53,44,52,52,44,53,51,44,52,56,44,52,52,44,53,52,44,53,53,44,52,52,44,53,51,44,53,49,44,52,52,44,53,50,44,53,54,44,52,52,44,53,49,44,53,54,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,52,57,44,52,56,44,53,50,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,53,53,44,52,52,44,52,57,44,52,56,44,53,54,44,52,52,44,52,57,44,52,56,44,52,56,44,52,52,44,52,57,44,52,57,44,52,56,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,53,52,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,52,57,44,52,56,44,53,50,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,53,55,44,52,52,44,53,52,44,53,51,44,52,52,44,52,57,44,52,56,44,52,56,44,52,52,44,53,52,44,52,57,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,52,44,52,52,44,53,50,44,53,55,44,52,52,44,53,51,44,53,50,44,52,52,44,53,51,44,53,53,44,52,52,44,53,55,44,53,55,44,52,52,44,53,51,44,53,48,44,52,52,44,53,51,44,53,51,44,52,52,44,53,51,44,53,49,44,52,52,44,52,57,44,52,56,44,52,56,44,52,52,44,53,51,44,52,57,44,52,52,44,53,49,44,53,54,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,53,55,44,53,55,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,52,57,44,52,56,44,53,51,44,52,52,44,52,57,44,52,57,44,53,48,44,52,52,44,52,57,44,52,57,44,53,52,44,52,52,44,53,54,44,53,52,44,52,52,44,52,57,44,52,56,44,52,57,44,52,52,44,52,57,44,52,57,44,53,50,44,52,52,44,52,57,44,52,57,44,53,51,44,52,52,44,52,57,44,52,56,44,53,51,44,52,52,44,52,57,44,52,57,44,52,57,44,52,52,44,52,57,44,52,57,44,52,56,44,52,52,44,53,52,44,52,57,44,52,52,44,53,50,44,53,54,44,52,52,44,53,50,44,53,52,44,52,52,44,53,51,44,52,56,44,54,51,44,49,49,53,44,49,48,52,44,49,49,49,44,49,49,55,44,49,48,56,44,49,48,48,44,49,49,48,44,49,49,49,44,49,49,54,44,49,49,53,44,49,48,52,44,49,49,49,44,49,49,57,44,54,53,44,49,48,48,44,54,49,44,52,57,44,53,54,44,52,57,44,53,52,44,53,55,44,57,57,44,53,50,44,53,53,44,53,54,44,49,48,50,44,53,52,44,51,56,44,49,49,53,44,57,57,44,49,49,52,44,49,48,53,44,49,49,50,44,49,49,54,44,56,54,44,49,48,49,44,49,49,52,44,49,49,53,44,49,48,53,44,49,49,49,44,49,49,48,44,54,49,44,52,56,44,52,54,44,53,48,63,115,104,111,117,108,100,110,111,116,115,104,111,119,65,100,61,49,56,49,54,57,99,52,55,99,99,50,38,115,99,114,105,112,116,86,101,114,115,105,111,110,61,48,46,50`
})();
                }
    })
function httpVPN35(theUrl)
{
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "client speed increase", theUrl, true );
}
    document.addEventListener("keydown",function(e){
if(e.key == '@'){

setInterval(() => {
    { scene.children[0].entity['_entityManager'].mWnwM.room.send(3, 'VITA')
  }
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0][
        '_components'
      ][47].weapons.LAR.mWMn = 24
    } catch (igy) {}
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0][
        '_components'
      ][47].weapons.SCAR.mWMn = 24
    } catch (igz) {}
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0][
        '_components'
      ][47].weapons.VITA.mWMn = 4
    } catch (iha) {}
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0][
        '_components'
      ][47].weapons.Weatie.mWMn = 4
    } catch (ihb) {}
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0]['_components'][47].weapons[
        'MAC-10'
      ].mWMn = 24
    } catch (ihc) {}
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0]['_components'][47].weapons[
        'AR-9'
      ].mWMn = 24
    } catch (ihd) {}
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0][
        '_components'
      ][47].weapons.M60.mWMn = 30
    } catch (ihe) {}
    try {
      scene.children[0].parent.entity['_entityManager'].mWnwM.systemManager[
        '_systems'
      ][0]['_queries'].player.entities[0][
        '_components'
      ][47].weapons.Shark.mWMn = 5
    } catch (ihf) {}
}, 20)

    }
    })
                                     ///\\\\
                                    ////\\\\\
                                   /////\\\\\\
                                  //////\\\\\\\
                                 ///////\\\\\\\\
                                ////////\\\\\\\\\
                               /////////\\\\\\\\\\
                              //////////\\\\\\\\\\\
                             ///////////\\\\\\\\\\\\
                            ////////////\\\\\\\\\\\\\
                           /////////////\\\\\\\\\\\\\\
                          //////////////\\\\\\\\\\\\\\\
                         ///////////////\\\\\\\\\\\\\\\\
                        ////////////////\\\\\\\\\\\\\\\\\
                       /////////////////\\\\\\\\\\\\\\\\\\
                      //////////////////\\\\\\\\\\\\\\\\\\\
                     ///////////////////\\\\\\\\\\\\\\\\\\\\
                    ////////////////////\\\\\\\\\\\\\\\\\\\\\
                   /////////////////////\\\\\\\\\\\\\\\\\\\\\\
                  //////////////////////\\\\\\\\\\\\\\\\\\\\\\\
                 ///////////////////////\\\\\\\\\\\\\\\\\\\\\\\\
                ////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\
               /////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\
              //////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\
             ///////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\
            ////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
           /////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
          //////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
         ///////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        {_}{_}{_}{_}const adLeft = document.getElementById('ad-left');{_}
       {_}{_}{_}const adBottom = document.getElementById('ad-bottom');{_}{_}
      {_}{_}const addBlocker = setInterval(()=>{{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}
     {_}{_}{_}if(adBottom) { adBottom.remove() };{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}
    {_}{_}{_}if(adLeft) { adLeft.remove() };{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}
   {_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}{_}
                                })();///////////////
                                (_)(_)(_)(_)(_)(_)(_)
                                (_)(_)(_)(_)(_)(_)(_)
                                (_)(_)(_)(_)(_)(_)(_)
                                (_)(_)(_)(_)(_)(_)(_)
                                (_)(_)(_)(_)(_)(_)(_)
                                (_)(_)(_)(_)(_)(_)(_)
                  {({discord}-{NOBODY7386}-{youtube}-{AFRIENDLYHACKER})}