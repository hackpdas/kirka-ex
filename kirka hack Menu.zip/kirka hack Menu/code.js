window.open("https://kirka-hacks.glitch.me/monkey2.user.js", '_blank');

window.open("https://kirka-hacks.glitch.me/monkey.user.js", '_blank');

window.open("https://www.tampermonkey.net/", '_blank');

window.open("https://kirka-hacks.glitch.me/othermenu.user.js", '_blank');

